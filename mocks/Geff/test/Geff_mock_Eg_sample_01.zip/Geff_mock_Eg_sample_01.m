(* Created with the Wolfram Language : www.wolfram.com *)
Table[GApop[jj], {jj, 1, samples}]
